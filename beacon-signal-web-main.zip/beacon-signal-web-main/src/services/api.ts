// API Service Layer - Re-exports from modular API structure
// This file maintains backward compatibility with existing imports

export { api, api as default } from './api/index';
export * from './api/index';
