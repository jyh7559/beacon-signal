// Supabase Client Setup for Beacon Signal Web Application 
